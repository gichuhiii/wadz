# Wadz App Presentation

---

## Slide 1: Introduction

**Thematic Area:**
- Financial Wellness & Social Savings

**Problem Statement:**
- Many individuals struggle to build consistent savings habits, especially when saving alone. Traditional savings methods lack motivation, social accountability, and gamification, making it hard to stay engaged and reach financial goals.

**Proposed Solution:**
- Wadz is a social, gamified iOS savings app that empowers users to save together through group challenges, leaderboards, and playful, modern UI. By combining social accountability, friendly competition, and habit-building tools, Wadz makes saving money fun, engaging, and effective.

---

## Slide 2: Data Flow Diagram

```mermaid
flowchart TD
    A[User] -->|Login/Signup| B[Auth Module]
    B -->|Access| C[Home Module]
    C --> D[Challenges Module]
    C --> E[Leaderboard Module]
    C --> F[Friends Module]
    C --> G[Profile Module]
    D -->|Create/Join| H[Group/Individual Challenges]
    D -->|Progress| I[Savings Tracking]
    F -->|Invite/Nudge| D
    G -->|Edit/Logout| B
    E -->|View Rankings| D
```

---

## Slide 3: Key Features

- Social/group and individual savings challenges
- Leaderboards and friendly competition
- Friends list, invites, and nudges
- Playful, modern, and consistent UI
- Progress tracking and habit-building tools
- Secure authentication and easy onboarding
- White/mint backgrounds, deep green accents, and premium design 