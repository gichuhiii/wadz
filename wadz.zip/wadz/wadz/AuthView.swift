import SwiftUI

struct AuthView: View {
    @Binding var isAuthenticated: Bool
    @State private var isLogin = true
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""

    var body: some View {
        ZStack {
            Color(hex: "E6F2ED").ignoresSafeArea()
            VStack {
                Spacer()
                VStack(spacing: 24) {
                    // Minimal icon/illustration
                    Image(systemName: "leaf.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 56, height: 56)
                        .foregroundColor(Color(hex: "034C45"))
                        .padding(.top, 16)
                    Text("Welcome to Wadz!")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .foregroundColor(Color(hex: "1B3333"))
                        .padding(.top, 4)
                    Text("Save together, build habits, and have fun!")
                        .font(.system(size: 16, weight: .medium, design: .rounded))
                        .foregroundColor(Color(hex: "034C45").opacity(0.7))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 16)
                }
                .padding(.bottom, 8)
                VStack(spacing: 0) {
                    VStack(spacing: 0) {
                        Picker("Auth", selection: $isLogin) {
                            Text("Login").tag(true)
                            Text("Sign Up").tag(false)
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding(.horizontal, 24)
                        .accentColor(Color(hex: "034C45"))
                        .padding(.top, 16)
                        VStack(spacing: 20) {
                            TextField("Email", text: $email)
                                .keyboardType(.emailAddress)
                                .autocapitalization(.none)
                                .padding()
                                .background(Color(hex: "E6F2ED"))
                                .cornerRadius(12)
                                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "034C45").opacity(0.12), lineWidth: 1))
                                .font(.system(size: 17, weight: .medium, design: .rounded))
                                .foregroundColor(Color(hex: "1B3333"))
                            SecureField("Password", text: $password)
                                .padding()
                                .background(Color(hex: "E6F2ED"))
                                .cornerRadius(12)
                                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "034C45").opacity(0.12), lineWidth: 1))
                                .font(.system(size: 17, weight: .medium, design: .rounded))
                                .foregroundColor(Color(hex: "1B3333"))
                            if !isLogin {
                                SecureField("Confirm Password", text: $confirmPassword)
                                    .padding()
                                    .background(Color(hex: "E6F2ED"))
                                    .cornerRadius(12)
                                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(hex: "034C45").opacity(0.12), lineWidth: 1))
                                    .font(.system(size: 17, weight: .medium, design: .rounded))
                                    .foregroundColor(Color(hex: "1B3333"))
                            }
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 24)
                    }
                    Button(action: {
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                            isAuthenticated = true
                        }
                    }) {
                        Text(isLogin ? "Login" : "Sign Up")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(hex: "034C45"))
                            .foregroundColor(.white)
                            .font(.system(size: 19, weight: .bold, design: .rounded))
                            .cornerRadius(14)
                            .shadow(color: Color(hex: "034C45").opacity(0.10), radius: 6, x: 0, y: 2)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 24)
                }
                .background(Color.white)
                .cornerRadius(28)
                .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 18, x: 0, y: 8)
                .padding(.horizontal, 16)
                .padding(.top, 24)
                Spacer()
            }
        }
    }
}

#Preview {
    AuthView(isAuthenticated: .constant(false))
} 