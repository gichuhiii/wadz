import SwiftUI

struct Friend: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let email: String
}

struct FriendsListView: View {
    @State private var friends: [Friend] = [
        Friend(name: "Alice Kimani", email: "alice@example.com"),
        Friend(name: "Brian Otieno", email: "brian@example.com"),
        Friend(name: "Carol Wanjiku", email: "carol@example.com"),
        Friend(name: "David Mwangi", email: "david@example.com"),
        Friend(name: "Eve Njeri", email: "eve@example.com")
    ]
    @State private var showInviteSheet = false
    @State private var inviteEmail = ""
    @State private var selectedTab = 0
    @State private var nudgedFriend: Friend? = nil
    @State private var showNudgeAlert = false
    @State private var showRemoveAlert = false
    @State private var friendToRemove: Friend? = nil

    var body: some View {
        NavigationView {
            ZStack {
                Color(hex: "E6F2ED").ignoresSafeArea()
                VStack(spacing: 0) {
                    Picker("View", selection: $selectedTab) {
                        Text("Friends").tag(0)
                        Text("Leaderboard").tag(1)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()
                    .background(Color.white)
                    .cornerRadius(16)
                    .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 6, x: 0, y: 2)
                    if selectedTab == 0 {
                        friendsList
                    } else {
                        LeaderboardView(
                            entries: [
                                LeaderboardEntry(name: "Alice Kimani", dailyAmount: 500, streak: 15),
                                LeaderboardEntry(name: "Brian Otieno", dailyAmount: 450, streak: 12),
                                LeaderboardEntry(name: "Carol Wanjiku", dailyAmount: 400, streak: 8),
                                LeaderboardEntry(name: "David Mwangi", dailyAmount: 350, streak: 5),
                                LeaderboardEntry(name: "Eve Njeri", dailyAmount: 300, streak: 3)
                            ],
                            currentUser: "Natasha Gichuhi"
                        )
                    }
                }
                .padding()
            }
            .navigationTitle("Friends")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    if selectedTab == 0 {
                        Button(action: { showInviteSheet = true }) {
                            Image(systemName: "person.badge.plus")
                                .foregroundColor(Color(hex: "034C45"))
                        }
                    }
                }
            }
            .sheet(isPresented: $showInviteSheet) {
                VStack(spacing: 20) {
                    Text("Invite a Friend").font(.headline)
                    TextField("Friend's email", text: $inviteEmail)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    Button("Send Invite") {
                        inviteFriend()
                    }
                    .disabled(inviteEmail.isEmpty)
                    Button("Cancel", role: .cancel) {
                        showInviteSheet = false
                        inviteEmail = ""
                    }
                }
                .padding()
            }
            .alert(isPresented: $showNudgeAlert) {
                Alert(title: Text("Nudge Sent!"), message: Text("You nudged \(nudgedFriend?.name ?? "") to save!"), dismissButton: .default(Text("OK")))
            }
            .alert(isPresented: $showRemoveAlert) {
                Alert(
                    title: Text("Security Check"),
                    message: Text("What is the name of your first pet? (Demo security question)"),
                    primaryButton: .destructive(Text("Remove")) {
                        if let friend = friendToRemove {
                            removeFriend(friend)
                        }
                        friendToRemove = nil
                    },
                    secondaryButton: .cancel {
                        friendToRemove = nil
                    }
                )
            }
        }
    }
    
    private var friendsList: some View {
        List {
            ForEach(friends) { friend in
                HStack {
                    VStack(alignment: .leading) {
                        Text(friend.name).font(.headline)
                        Text(friend.email).font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                    Button(action: { nudge(friend) }) {
                        Image(systemName: "hand.wave.fill")
                            .foregroundColor(.orange)
                        Text("Nudge")
                            .font(.caption)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    Button(action: { friendToRemove = friend; showRemoveAlert = true }) {
                        Image(systemName: "person.crop.circle.badge.minus")
                            .foregroundColor(.red)
                    }
                }
            }
            .onDelete(perform: deleteFriend)
        }
    }

    private func nudge(_ friend: Friend) {
        nudgedFriend = friend
        showNudgeAlert = true
    }

    private func removeFriend(_ friend: Friend) {
        if let index = friends.firstIndex(of: friend) {
            friends.remove(at: index)
        }
    }

    private func deleteFriend(at offsets: IndexSet) {
        friends.remove(atOffsets: offsets)
    }

    private func inviteFriend() {
        // Mock invite logic
        showInviteSheet = false
        inviteEmail = ""
    }
}

#Preview {
    FriendsListView()
} 