//
//  Models.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import Foundation
import SwiftUI

// MARK: - Challenge Model
struct Challenge: Identifiable, Codable {
    let id = UUID()
    let title: String
    let description: String
    let targetAmount: Double
    let dailyAmount: Double
    let duration: Int // in days
    let category: ChallengeCategory
    let participants: [String] // user IDs
    let createdDate: Date
    let endDate: Date
    var isActive: Bool
    var totalSaved: Double
    
    var progress: Double {
        return totalSaved / targetAmount
    }
    
    var daysRemaining: Int {
        let calendar = Calendar.current
        return calendar.dateComponents([.day], from: Date(), to: endDate).day ?? 0
    }

    var isGroupChallenge: Bool {
        participants.count > 1
    }
}

enum ChallengeCategory: String, CaseIterable, Codable {
    case personal = "Personal Goal"
    case education = "Education Fund"
    case emergency = "Emergency Fund"
    case travel = "Travel Fund"
    case business = "Business Startup"
    case health = "Health & Wellness"
    case other = "Other"
    
    var icon: String {
        switch self {
        case .personal: return "person.fill"
        case .education: return "graduationcap.fill"
        case .emergency: return "shield.fill"
        case .travel: return "airplane"
        case .business: return "briefcase.fill"
        case .health: return "heart.fill"
        case .other: return "questionmark.circle.fill"
        }
    }
    
    var color: Color {
        switch self {
        case .personal: return .blue
        case .education: return .purple
        case .emergency: return .red
        case .travel: return .orange
        case .business: return .green
        case .health: return .pink
        case .other: return .gray
        }
    }
}

// MARK: - User Model
struct User: Identifiable, Codable {
    let id = UUID()
    let name: String
    let email: String
    let profileImageURL: String?
    var totalSaved: Double
    var currentStreak: Int
    var longestStreak: Int
    var badges: [Badge]
    var joinedChallenges: [String] // challenge IDs
    var createdChallenges: [String] // challenge IDs
    let joinDate: Date
}

// MARK: - Savings Entry Model
struct SavingsEntry: Identifiable, Codable {
    let id = UUID()
    let challengeId: String
    let userId: String
    let amount: Double
    let date: Date
    let note: String?
}

// MARK: - Badge Model
struct Badge: Identifiable, Codable {
    let id = UUID()
    let title: String
    let description: String
    let iconName: String
    let earnedDate: Date
    let category: BadgeCategory
}

enum BadgeCategory: String, CaseIterable, Codable {
    case streak = "Streak Master"
    case amount = "Big Saver"
    case consistency = "Consistent Saver"
    case social = "Team Player"
    case milestone = "Milestone Achiever"
    
    var color: Color {
        switch self {
        case .streak: return .orange
        case .amount: return .green
        case .consistency: return .blue
        case .social: return .purple
        case .milestone: return .yellow
        }
    }
}

// MARK: - Sample Data
extension Challenge {
    static let sampleChallenges = [
        Challenge(
            title: "Save KSh 50 Daily",
            description: "Build a habit of saving small amounts consistently for 30 days",
            targetAmount: 1500,
            dailyAmount: 50,
            duration: 30,
            category: .personal,
            participants: ["Alice Kimani"],
            createdDate: Date().addingTimeInterval(-86400 * 5),
            endDate: Date().addingTimeInterval(86400 * 25),
            isActive: true,
            totalSaved: 750
        ),
        Challenge(
            title: "Emergency Fund Challenge",
            description: "Build an emergency fund covering 3 months of expenses",
            targetAmount: 50000,
            dailyAmount: 500,
            duration: 100,
            category: .emergency,
            participants: ["Alice Kimani", "Brian Otieno", "Carol Wanjiku"],
            createdDate: Date().addingTimeInterval(-86400 * 10),
            endDate: Date().addingTimeInterval(86400 * 90),
            isActive: true,
            totalSaved: 12500
        ),
        Challenge(
            title: "Education Fund",
            description: "Save for that certification course you've been wanting to take",
            targetAmount: 25000,
            dailyAmount: 250,
            duration: 100,
            category: .education,
            participants: ["Brian Otieno", "Carol Wanjiku"],
            createdDate: Date().addingTimeInterval(-86400 * 2),
            endDate: Date().addingTimeInterval(86400 * 98),
            isActive: true,
            totalSaved: 2000
        ),
        Challenge(
            title: "Solo Health Goal",
            description: "Save for a gym membership on your own!",
            targetAmount: 12000,
            dailyAmount: 400,
            duration: 30,
            category: .health,
            participants: ["David Mwangi"],
            createdDate: Date().addingTimeInterval(-86400 * 3),
            endDate: Date().addingTimeInterval(86400 * 27),
            isActive: true,
            totalSaved: 1600
        ),
        Challenge(
            title: "Travel with Friends",
            description: "Save for a group trip to the coast!",
            targetAmount: 30000,
            dailyAmount: 600,
            duration: 50,
            category: .travel,
            participants: ["Alice Kimani", "Brian Otieno", "Carol Wanjiku", "David Mwangi", "Eve Njeri"],
            createdDate: Date().addingTimeInterval(-86400 * 1),
            endDate: Date().addingTimeInterval(86400 * 49),
            isActive: true,
            totalSaved: 5000
        ),
        Challenge(
            title: "Personal Business Fund",
            description: "Save up to start your own side hustle.",
            targetAmount: 20000,
            dailyAmount: 400,
            duration: 50,
            category: .business,
            participants: ["Eve Njeri"],
            createdDate: Date().addingTimeInterval(-86400 * 7),
            endDate: Date().addingTimeInterval(86400 * 43),
            isActive: true,
            totalSaved: 3200
        )
    ]
}

extension Badge {
    static let sampleBadges = [
        Badge(
            title: "First Step",
            description: "Made your first savings entry",
            iconName: "star.fill",
            earnedDate: Date().addingTimeInterval(-86400 * 7),
            category: .milestone
        ),
        Badge(
            title: "Week Warrior",
            description: "Saved consistently for 7 days",
            iconName: "flame.fill",
            earnedDate: Date().addingTimeInterval(-86400 * 3),
            category: .streak
        ),
        Badge(
            title: "Team Player",
            description: "Joined your first group challenge",
            iconName: "person.3.fill",
            earnedDate: Date().addingTimeInterval(-86400 * 5),
            category: .social
        )
    ]
} 