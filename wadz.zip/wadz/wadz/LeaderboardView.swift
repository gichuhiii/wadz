import SwiftUI

struct LeaderboardEntry: Identifiable {
    let id = UUID()
    let name: String
    let dailyAmount: Double
    let streak: Int
}

struct LeaderboardView: View {
    let entries: [LeaderboardEntry]
    let currentUser: String
    @State private var nudgedName: String? = nil
    @State private var showNudgeAlert = false
    
    var body: some View {
        ZStack {
            Color(hex: "E6F2ED").ignoresSafeArea()
            VStack(spacing: 24) {
                Text("Leaderboard")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundColor(Color(hex: "1B3333"))
                let allEntries = entries + (entries.contains(where: { $0.name == currentUser }) ? [] : [LeaderboardEntry(name: currentUser, dailyAmount: 0, streak: 0)])
                ForEach(allEntries.enumerated().map { $0 }, id: \ .element.id) { index, entry in
                    HStack {
                        ZStack {
                            Circle()
                                .fill(entry.name == currentUser ? Color.green.opacity(0.25) : Color(hex: "034C45").opacity(index == 0 ? 0.18 : 0.10))
                                .frame(width: 36, height: 36)
                            if index == 0 {
                                Image(systemName: "medal.fill")
                                    .foregroundColor(Color(hex: "FFD700"))
                                    .font(.system(size: 18))
                            } else if index == 1 {
                                Image(systemName: "medal.fill")
                                    .foregroundColor(Color(hex: "C0C0C0"))
                                    .font(.system(size: 18))
                            } else if index == 2 {
                                Image(systemName: "medal.fill")
                                    .foregroundColor(Color(hex: "CD7F32"))
                                    .font(.system(size: 18))
                            } else {
                                Text(initials(for: entry.name))
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color(hex: "034C45"))
                            }
                        }
                        VStack(alignment: .leading, spacing: 4) {
                            Text(entry.name + (entry.name == currentUser ? " (You)" : ""))
                                .font(.system(size: 18, weight: .semibold, design: .rounded))
                                .foregroundColor(entry.name == currentUser ? .green : Color(hex: "1B3333"))
                            Text("Daily: KSh \(Int(entry.dailyAmount))")
                                .font(.system(size: 15, weight: .medium, design: .rounded))
                                .foregroundColor(Color(hex: "034C45").opacity(0.7))
                        }
                        Spacer()
                        Text("Streak: \(entry.streak)")
                            .font(.system(size: 15, weight: .medium, design: .rounded))
                            .foregroundColor(Color(hex: "034C45").opacity(0.7))
                        if entry.name != currentUser {
                            Button(action: {
                                nudgedName = entry.name
                                showNudgeAlert = true
                            }) {
                                Image(systemName: "hand.point.right.fill")
                                    .foregroundColor(Color(hex: "034C45"))
                                    .padding(6)
                                    .background(Color(hex: "E6F2ED"))
                                    .cornerRadius(8)
                            }
                            .buttonStyle(BorderlessButtonStyle())
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(16)
                    .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 8, x: 0, y: 2)
                }
                Spacer()
            }
            .padding()
        }
        .alert(isPresented: $showNudgeAlert) {
            Alert(title: Text("Poke Sent!"), message: Text("You poked \(nudgedName ?? "") to save!"), dismissButton: .default(Text("OK")))
        }
    }
    private func initials(for name: String) -> String {
        let comps = name.split(separator: " ")
        return comps.prefix(2).map { String($0.prefix(1)) }.joined().uppercased()
    }
}

#Preview {
    LeaderboardView(
        entries: [
            LeaderboardEntry(name: "Alice Kimani", dailyAmount: 500, streak: 15),
            LeaderboardEntry(name: "Brian Otieno", dailyAmount: 450, streak: 12),
            LeaderboardEntry(name: "Carol Wanjiku", dailyAmount: 400, streak: 8),
            LeaderboardEntry(name: "David Mwangi", dailyAmount: 350, streak: 5),
            LeaderboardEntry(name: "Eve Njeri", dailyAmount: 300, streak: 3)
        ],
        currentUser: "Alice Kimani"
    )
} 