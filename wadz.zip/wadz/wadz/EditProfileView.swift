//
//  EditProfileView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct EditProfileView: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var user: User
    @State private var name: String = ""
    @State private var email: String = ""
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                // Profile image
                VStack(spacing: 16) {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(
                                colors: [.green, .blue],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ))
                            .frame(width: 100, height: 100)
                        
                        Text(String(name.isEmpty ? user.name : name).prefix(2).uppercased())
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                    }
                    
                    Button("Change Photo") {
                        // Handle photo change
                    }
                    .foregroundColor(.green)
                }
                .padding(.top)
                
                // Form
                VStack(spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Name")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        TextField("Your name", text: $name)
                            .textFieldStyle(.plain)
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Email")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        TextField("your.email@example.com", text: $email)
                            .textFieldStyle(.plain)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .navigationTitle("Edit Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveProfile()
                    }
                    .fontWeight(.semibold)
                    .foregroundColor(.green)
                }
            }
        }
        .onAppear {
            name = user.name
            email = user.email
        }
    }
    
    private func saveProfile() {
        // Update user with new information
        // In a real app, you'd save this to your backend
        print("Saved profile: \(name), \(email)")
        presentationMode.wrappedValue.dismiss()
    }
}

#Preview {
    EditProfileView(user: .constant(User(
        name: "Natasha Gichuhi",
        email: "natasha@example.com",
        profileImageURL: nil,
        totalSaved: 15750,
        currentStreak: 12,
        longestStreak: 28,
        badges: Badge.sampleBadges,
        joinedChallenges: ["1", "2"],
        createdChallenges: ["1"],
        joinDate: Date()
    )))
} 