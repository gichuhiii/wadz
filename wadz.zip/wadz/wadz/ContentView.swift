//
//  ContentView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct ContentView: View {
    @Binding var isAuthenticated: Bool
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
                .tag(0)
            
            ChallengesView()
                .tabItem {
                    Image(systemName: "target")
                    Text("Challenges")
                }
                .tag(1)
            
            LeaderboardView(
                entries: [
                    LeaderboardEntry(name: "Alice Kimani", dailyAmount: 500, streak: 15),
                    LeaderboardEntry(name: "Brian Otieno", dailyAmount: 450, streak: 12),
                    LeaderboardEntry(name: "Carol Wanjiku", dailyAmount: 400, streak: 8),
                    LeaderboardEntry(name: "David Mwangi", dailyAmount: 350, streak: 5),
                    LeaderboardEntry(name: "Eve Njeri", dailyAmount: 300, streak: 3),
                    LeaderboardEntry(name: "Natasha Gichuhi", dailyAmount: 100, streak: 15)
                ],
                currentUser: "Natasha Gichuhi"
            )
                .tabItem {
                    Image(systemName: "trophy.fill")
                    Text("Leaderboard")
                }
                .tag(2)
            
            ProfileView(onLogout: { isAuthenticated = false })
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
                .tag(3)
        }
        .accentColor(Color(hex: "034C45"))
        .background(Color(hex: "E6F2ED").ignoresSafeArea())
    }
}

#Preview {
    ContentView(isAuthenticated: .constant(true))
}
