//
//  HomeView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct HomeView: View {
    @State private var currentUser = User(
        name: "Natasha Gichuhi",
        email: "natasha@example.com",
        profileImageURL: nil,
        totalSaved: 15750,
        currentStreak: 15,
        longestStreak: 28,
        badges: Badge.sampleBadges,
        joinedChallenges: ["1", "2"],
        createdChallenges: ["1"],
        joinDate: Date().addingTimeInterval(-86400 * 30)
    )
    
    @State private var activeChallenges = Challenge.sampleChallenges
    @State private var showingAddSavings = false
    @State private var showingCreateChallenge = false
    @State private var showingFriendsList = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    headerView
                    quickStatsView
                    activeChallengesView
                    quickActionsView
                }
                .padding()
                .background(Color(hex: "E6F2ED").ignoresSafeArea())
            }
            .navigationTitle("Wadz")
            .navigationBarTitleDisplayMode(.large)
            .background(Color(hex: "E6F2ED").ignoresSafeArea())
            .sheet(isPresented: $showingAddSavings) {
                AddSavingsView()
            }
            .sheet(isPresented: $showingCreateChallenge) {
                CreateChallengeView()
            }
            .sheet(isPresented: $showingFriendsList) {
                FriendsListView()
            }
        }
    }
    
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading) {
                    Text("Good morning,")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    Text(currentUser.name)
                        .font(.title)
                        .fontWeight(.bold)
                }
                Spacer()
                
                // Streak indicator
                VStack {
                    Image(systemName: "flame.fill")
                        .foregroundColor(.orange)
                        .font(.title2)
                    Text("\(currentUser.currentStreak)")
                        .font(.headline)
                        .fontWeight(.bold)
                    Text("day streak")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(Color(.white))
                .cornerRadius(12)
            }
        }
    }
    
    private var quickStatsView: some View {
        HStack(spacing: 15) {
            StatCard(
                title: "Total Saved",
                value: "KSh \(Int(currentUser.totalSaved))",
                icon: "banknote.fill",
                color: .green
            )
            
            StatCard(
                title: "Active Goals",
                value: "\(activeChallenges.filter { $0.isActive }.count)",
                icon: "target",
                color: .blue
            )
            
            StatCard(
                title: "Badges Earned",
                value: "\(currentUser.badges.count)",
                icon: "star.fill",
                color: .yellow
            )
        }
    }
    
    private var activeChallengesView: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Active Challenges")
                    .font(.headline)
                    .fontWeight(.semibold)
                Spacer()
                Button("See All") {
                    // Navigate to challenges view
                }
                .foregroundColor(.green)
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    ForEach(activeChallenges.filter { $0.isActive }.prefix(3)) { challenge in
                        ChallengeCard(challenge: challenge)
                    }
                }
                .padding(.horizontal, 5)
            }
        }
    }
    
    private var quickActionsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick Actions")
                .font(.headline)
                .fontWeight(.semibold)
            
            HStack(spacing: 15) {
                ActionButton(
                    title: "Add Savings",
                    icon: "plus.circle.fill",
                    color: .green
                ) {
                    showingAddSavings = true
                }
                
                ActionButton(
                    title: "New Challenge",
                    icon: "target",
                    color: .blue
                ) {
                    showingCreateChallenge = true
                }
                
                ActionButton(
                    title: "Find Friends",
                    icon: "person.3.fill",
                    color: .purple
                ) {
                    showingFriendsList = true
                }
            }
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(Color(hex: "034C45"))
                .font(.title2)
            
            Text(value)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(Color(hex: "1B3333"))
            
            Text(title)
                .font(.caption)
                .foregroundColor(Color(hex: "034C45").opacity(0.7))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 6, x: 0, y: 2)
    }
}

struct ChallengeCard: View {
    let challenge: Challenge
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: challenge.category.icon)
                    .foregroundColor(Color(hex: "034C45"))
                    .font(.title2)
                Spacer()
                Text("\(challenge.daysRemaining) days left")
                    .font(.caption)
                    .foregroundColor(Color(hex: "034C45").opacity(0.7))
            }
            
            Text(challenge.title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(Color(hex: "1B3333"))
                .lineLimit(2)
            
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("KSh \(Int(challenge.totalSaved))")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(Color(hex: "1B3333"))
                    Spacer()
                    Text("KSh \(Int(challenge.targetAmount))")
                        .font(.subheadline)
                        .foregroundColor(Color(hex: "034C45").opacity(0.7))
                }
                
                ProgressView(value: challenge.progress)
                    .progressViewStyle(LinearProgressViewStyle(tint: Color(hex: "034C45")))
                
                Text("\(Int(challenge.progress * 100))% complete")
                    .font(.caption)
                    .foregroundColor(Color(hex: "034C45").opacity(0.7))
            }
        }
        .padding()
        .frame(width: 280)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 6, x: 0, y: 2)
    }
}

struct ActionButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(color)
                
                Text(title)
                    .font(.caption)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(.white))
            .cornerRadius(12)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    HomeView()
} 
