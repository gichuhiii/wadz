//
//  wadzApp.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

@main
struct wadzApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
