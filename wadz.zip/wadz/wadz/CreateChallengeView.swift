//
//  CreateChallengeView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct CreateChallengeView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var title: String = ""
    @State private var description: String = ""
    @State private var targetAmount: String = ""
    @State private var dailyAmount: String = ""
    @State private var duration: String = ""
    @State private var selectedCategory: ChallengeCategory = .personal
    @State private var isPublic: Bool = true
    @State private var isGroupChallenge: Bool = false
    @State private var selectedFriends: Set<String> = []
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Header
                    VStack(spacing: 8) {
                        Image(systemName: "target")
                            .foregroundColor(.blue)
                            .font(.system(size: 60))
                        
                        Text("Create Challenge")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text("Start a new savings goal and invite others to join")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top)
                    
                    // Form
                    VStack(spacing: 20) {
                        // Challenge type selection
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Challenge Type")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            Picker("Challenge Type", selection: $isGroupChallenge) {
                                Text("Individual Challenge").tag(false)
                                Text("Group Challenge").tag(true)
                            }
                            .pickerStyle(SegmentedPickerStyle())
                        }
                        
                        // Challenge title
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Challenge Title")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            TextField("e.g., Save for vacation", text: $title)
                                .textFieldStyle(.plain)
                                .padding()
                                .background(Color(.systemGray6))
                                .cornerRadius(12)
                        }
                        
                        // Description
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Description")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            TextField("Describe your savings goal...", text: $description, axis: .vertical)
                                .textFieldStyle(.plain)
                                .padding()
                                .background(Color(.systemGray6))
                                .cornerRadius(12)
                                .lineLimit(3...6)
                        }
                        
                        // Category selection
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Category")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 12) {
                                ForEach(ChallengeCategory.allCases, id: \.self) { category in
                                    CategorySelectionCard(
                                        category: category,
                                        isSelected: selectedCategory == category
                                    ) {
                                        selectedCategory = category
                                    }
                                }
                            }
                        }
                        
                        // Group challenge specific: Friend selection
                        if isGroupChallenge {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Invite Friends")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                
                                VStack(spacing: 8) {
                                    ForEach(sampleFriends, id: \.self) { friend in
                                        Button(action: {
                                            if selectedFriends.contains(friend) {
                                                selectedFriends.remove(friend)
                                            } else {
                                                selectedFriends.insert(friend)
                                            }
                                        }) {
                                            HStack {
                                                Image(systemName: selectedFriends.contains(friend) ? "checkmark.circle.fill" : "circle")
                                                    .foregroundColor(selectedFriends.contains(friend) ? .green : .gray)
                                                Text(friend)
                                                    .foregroundColor(.primary)
                                                Spacer()
                                            }
                                            .padding()
                                            .background(Color(.systemGray6))
                                            .cornerRadius(8)
                                        }
                                        .buttonStyle(PlainButtonStyle())
                                    }
                                }
                            }
                        }
                        
                        // Financial details
                        VStack(spacing: 16) {
                            Text("Financial Details")
                                .font(.headline)
                                .fontWeight(.semibold)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Target Amount")
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                    
                                    HStack {
                                        Text("KSh")
                                            .foregroundColor(.secondary)
                                        TextField("5000", text: $targetAmount)
                                            .keyboardType(.numberPad)
                                    }
                                    .padding()
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                                }
                                
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Daily Goal")
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                    
                                    HStack {
                                        Text("KSh")
                                            .foregroundColor(.secondary)
                                        TextField("100", text: $dailyAmount)
                                            .keyboardType(.numberPad)
                                    }
                                    .padding()
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                                }
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Duration (Days)")
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                                
                                TextField("30", text: $duration)
                                    .keyboardType(.numberPad)
                                    .padding()
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                            }
                            
                            // Calculation preview
                            if let target = Double(targetAmount),
                               let daily = Double(dailyAmount),
                               let days = Int(duration),
                               target > 0 && daily > 0 && days > 0 {
                                
                                let calculatedTarget = daily * Double(days)
                                
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Calculation Preview")
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Daily goal: KSh \(Int(daily))")
                                        Text("Duration: \(days) days")
                                        Text("Total: KSh \(Int(calculatedTarget))")
                                        
                                        if abs(target - calculatedTarget) > 1 {
                                            VStack(alignment: .trailing) {
                                                Text("Target difference:")
                                                    .font(.caption)
                                                    .foregroundColor(.secondary)
                                                Text("KSh \(Int(abs(target - calculatedTarget)))")
                                                    .font(.subheadline)
                                                    .fontWeight(.medium)
                                                    .foregroundColor(target > calculatedTarget ? .orange : .green)
                                            }
                                        }
                                    }
                                    .padding()
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                                }
                            }
                        }
                        
                        // Privacy settings
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Privacy")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            Toggle(isOn: $isPublic) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Public Challenge")
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                    Text("Others can find and join this challenge")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                            .tint(.green)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Create") {
                        createChallenge()
                    }
                    .fontWeight(.semibold)
                    .foregroundColor(canCreate ? .green : .secondary)
                    .disabled(!canCreate)
                }
            }
        }
    }
    
    private var sampleFriends: [String] {
        ["Alice Kimani", "Brian Otieno", "Carol Wanjiku", "David Mwangi"]
    }
    
    private var canCreate: Bool {
        !title.isEmpty &&
        !description.isEmpty &&
        !targetAmount.isEmpty &&
        !dailyAmount.isEmpty &&
        !duration.isEmpty &&
        Double(targetAmount) != nil &&
        Double(dailyAmount) != nil &&
        Int(duration) != nil &&
        Double(targetAmount)! > 0 &&
        Double(dailyAmount)! > 0 &&
        Int(duration)! > 0 &&
        (!isGroupChallenge || !selectedFriends.isEmpty)
    }
    
    private func createChallenge() {
        guard canCreate,
              let target = Double(targetAmount),
              let daily = Double(dailyAmount),
              let days = Int(duration) else { return }
        
        // Here you would normally save to your data store
        print("Created challenge: \(title)")
        print("Type: \(isGroupChallenge ? "Group" : "Individual")")
        print("Category: \(selectedCategory.rawValue)")
        print("Target: KSh \(target)")
        print("Daily: KSh \(daily)")
        print("Duration: \(days) days")
        print("Public: \(isPublic)")
        if isGroupChallenge {
            print("Invited friends: \(selectedFriends)")
        }
        
        presentationMode.wrappedValue.dismiss()
    }
}

struct CategorySelectionCard: View {
    let category: ChallengeCategory
    let isSelected: Bool
    let onSelect: () -> Void
    
    var body: some View {
        Button(action: onSelect) {
            VStack(spacing: 8) {
                Image(systemName: category.icon)
                    .foregroundColor(category.color)
                    .font(.title2)
                
                Text(category.rawValue)
                    .font(.caption)
                    .fontWeight(.medium)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .padding()
            .frame(maxWidth: .infinity, minHeight: 80)
            .background(isSelected ? category.color.opacity(0.1) : Color(.systemGray6))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? category.color : Color.clear, lineWidth: 2)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    CreateChallengeView()
} 