import SwiftUI

struct SplashScreenView: View {
    @State private var isActive = false

    var body: some View {
        ZStack {
            Color(hex: "E6F2ED").ignoresSafeArea()
            VStack {
                Spacer()
                VStack(spacing: 24) {
                    Image(systemName: "leaf.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 64, height: 64)
                        .foregroundColor(Color(hex: "034C45"))
                        .padding(.top, 16)
                    Text("Wadz")
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(Color(hex: "1B3333"))
                        .padding(.top, 4)
                    Text("Save together, build habits, and have fun!")
                        .font(.system(size: 16, weight: .medium, design: .rounded))
                        .foregroundColor(Color(hex: "034C45").opacity(0.7))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 16)
                }
                .padding(.vertical, 32)
                .padding(.horizontal, 32)
                .background(Color.white)
                .cornerRadius(28)
                .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 18, x: 0, y: 8)
                Spacer()
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: Color(hex: "034C45")))
                    .scaleEffect(1.5)
                    .padding(.bottom, 40)
            }
        }
    }
}

#Preview {
    SplashScreenView()
} 