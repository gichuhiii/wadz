import SwiftUI

struct RootView: View {
    @State private var showSplash = true
    @State private var isAuthenticated = false // Replace with real auth logic

    var body: some View {
        Group {
            if showSplash {
                SplashScreenView()
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            showSplash = false
                        }
                    }
            } else if !isAuthenticated {
                AuthView(isAuthenticated: $isAuthenticated)
            } else {
                ContentView(isAuthenticated: $isAuthenticated)
            }
        }
    }
}

#Preview {
    RootView()
} 