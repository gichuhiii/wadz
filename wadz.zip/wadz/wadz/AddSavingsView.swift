//
//  AddSavingsView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct AddSavingsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedChallenge: Challenge?
    @State private var amount: String = ""
    @State private var note: String = ""
    @State private var availableChallenges = Challenge.sampleChallenges.filter { $0.isActive }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                // Header
                VStack(spacing: 8) {
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(.green)
                        .font(.system(size: 60))
                    
                    Text("Add Savings")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("Record your savings progress")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding(.top)
                
                // Form
                VStack(spacing: 20) {
                    // Challenge selection
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Select Challenge")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        if availableChallenges.isEmpty {
                            Text("No active challenges available")
                                .foregroundColor(.secondary)
                                .italic()
                        } else {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 12) {
                                    ForEach(availableChallenges) { challenge in
                                        ChallengeSelectionCard(
                                            challenge: challenge,
                                            isSelected: selectedChallenge?.id == challenge.id
                                        ) {
                                            selectedChallenge = challenge
                                        }
                                    }
                                }
                                .padding(.horizontal, 2)
                            }
                        }
                    }
                    
                    // Amount input
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Amount (KSh)")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        HStack {
                            Text("KSh")
                                .foregroundColor(.secondary)
                            
                            TextField("0", text: $amount)
                                .keyboardType(.numberPad)
                                .font(.title2)
                                .fontWeight(.medium)
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                    }
                    
                    // Quick amount buttons
                    if let challenge = selectedChallenge {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Quick Amount")
                                .font(.subheadline)
                                .fontWeight(.medium)
                                .foregroundColor(.secondary)
                            
                            HStack(spacing: 12) {
                                QuickAmountButton(
                                    amount: Int(challenge.dailyAmount),
                                    label: "Daily Goal"
                                ) {
                                    amount = String(Int(challenge.dailyAmount))
                                }
                                
                                QuickAmountButton(
                                    amount: Int(challenge.dailyAmount * 0.5),
                                    label: "Half Goal"
                                ) {
                                    amount = String(Int(challenge.dailyAmount * 0.5))
                                }
                                
                                QuickAmountButton(
                                    amount: Int(challenge.dailyAmount * 2),
                                    label: "Double Goal"
                                ) {
                                    amount = String(Int(challenge.dailyAmount * 2))
                                }
                            }
                        }
                    }
                    
                    // Note input
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Note (Optional)")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        TextField("Add a note about this savings...", text: $note, axis: .vertical)
                            .textFieldStyle(.plain)
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                            .lineLimit(3...6)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
                
                // Save button
                Button(action: saveSavings) {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                        Text("Save Progress")
                    }
                    .font(.headline)
                    .fontWeight(.medium)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(canSave ? Color.green : Color.gray)
                    .cornerRadius(12)
                }
                .disabled(!canSave)
                .padding(.horizontal)
                .padding(.bottom)
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
    
    private var canSave: Bool {
        selectedChallenge != nil && !amount.isEmpty && Double(amount) != nil && Double(amount)! > 0
    }
    
    private func saveSavings() {
        guard let challenge = selectedChallenge,
              let amountValue = Double(amount),
              amountValue > 0 else { return }
        
        // Here you would normally save to your data store
        // For now, just simulate the action
        print("Saved \(amountValue) KSh to \(challenge.title)")
        if !note.isEmpty {
            print("Note: \(note)")
        }
        
        presentationMode.wrappedValue.dismiss()
    }
}

struct ChallengeSelectionCard: View {
    let challenge: Challenge
    let isSelected: Bool
    let onSelect: () -> Void
    
    var body: some View {
        Button(action: onSelect) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: challenge.category.icon)
                        .foregroundColor(challenge.category.color)
                        .font(.title3)
                    Spacer()
                    if isSelected {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                    }
                }
                
                Text(challenge.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                
                Text("Goal: KSh \(Int(challenge.dailyAmount))/day")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
            .frame(width: 160, height: 100)
            .background(isSelected ? challenge.category.color.opacity(0.1) : Color(.systemGray6))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? challenge.category.color : Color.clear, lineWidth: 2)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

struct QuickAmountButton: View {
    let amount: Int
    let label: String
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 4) {
                Text("KSh \(amount)")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Text(label)
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(.systemGray6))
            .cornerRadius(8)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    AddSavingsView()
} 