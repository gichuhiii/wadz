//
//  ProgressView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct SavingsProgressView: View {
    @State private var selectedTimeframe: TimeFrame = .week
    @State private var savingsData = generateSampleSavingsData()
    @State private var userBadges = Badge.sampleBadges
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Overview stats
                    overviewSection
                    
                    // Savings chart
                    savingsChartSection
                    
                    // Achievements section
                    achievementsSection
                    
                    // Recent activity
                    recentActivitySection
                }
                .padding()
            }
            .navigationTitle("Progress")
            .navigationBarTitleDisplayMode(.large)
        }
    }
    
    private var overviewSection: some View {
        VStack(spacing: 16) {
            Text("Your Savings Journey")
                .font(.headline)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 12) {
                ProgressStatCard(
                    title: "Total Saved",
                    value: "KSh 15,750",
                    subtitle: "+12% this month",
                    color: .green,
                    icon: "banknote.fill"
                )
                
                ProgressStatCard(
                    title: "Current Streak",
                    value: "12 days",
                    subtitle: "Personal best: 28",
                    color: .orange,
                    icon: "flame.fill"
                )
            }
            
            HStack(spacing: 12) {
                ProgressStatCard(
                    title: "Goals Achieved",
                    value: "3 of 5",
                    subtitle: "60% completion",
                    color: .blue,
                    icon: "target"
                )
                
                ProgressStatCard(
                    title: "Average Daily",
                    value: "KSh 125",
                    subtitle: "Above target",
                    color: .purple,
                    icon: "chart.line.uptrend.xyaxis"
                )
            }
        }
    }
    
    private var savingsChartSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Savings Trend")
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                // Time frame picker
                Picker("Time Frame", selection: $selectedTimeframe) {
                    Text("Week").tag(TimeFrame.week)
                    Text("Month").tag(TimeFrame.month)
                    Text("Year").tag(TimeFrame.year)
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: 200)
            }
            
            // Chart placeholder (since Charts might not be available in all iOS versions)
            VStack {
                HStack {
                    ForEach(savingsData.prefix(7), id: \.date) { data in
                        VStack {
                            Rectangle()
                                .fill(Color.green)
                                .frame(width: 20, height: CGFloat(data.amount / 10))
                                .cornerRadius(4)
                            
                            Text("\(Calendar.current.component(.day, from: data.date))")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        
                        if data != savingsData.last {
                            Spacer()
                        }
                    }
                }
                .frame(height: 120)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
            }
        }
    }
    
    private var achievementsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Recent Achievements")
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Button("View All") {
                    // Navigate to all badges
                }
                .foregroundColor(.green)
            }
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
                ForEach(userBadges.prefix(6)) { badge in
                    BadgeCard(badge: badge)
                }
            }
        }
    }
    
    private var recentActivitySection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Recent Activity")
                .font(.headline)
                .fontWeight(.semibold)
            
            VStack(spacing: 12) {
                ForEach(generateRecentActivities(), id: \.id) { activity in
                    ActivityRow(activity: activity)
                }
            }
        }
    }
}

struct ProgressStatCard: View {
    let title: String
    let value: String
    let subtitle: String
    let color: Color
    let icon: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(Color(hex: "034C45"))
                    .font(.title3)
                Spacer()
            }
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(Color(hex: "1B3333"))
            Text(title)
                .font(.caption)
                .foregroundColor(Color(hex: "034C45").opacity(0.7))
            Text(subtitle)
                .font(.caption2)
                .foregroundColor(Color(hex: "034C45").opacity(0.7))
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 6, x: 0, y: 2)
    }
}

struct BadgeCard: View {
    let badge: Badge
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: badge.iconName)
                .foregroundColor(badge.category.color)
                .font(.title2)
                .frame(width: 40, height: 40)
                .background(badge.category.color.opacity(0.1))
                .cornerRadius(8)
            
            Text(badge.title)
                .font(.caption)
                .fontWeight(.medium)
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
        .padding(8)
        .frame(maxWidth: .infinity)
        .background(Color(.systemBackground))
        .cornerRadius(8)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}

struct ActivityRow: View {
    let activity: RecentActivity
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: activity.icon)
                .foregroundColor(activity.color)
                .font(.title3)
                .frame(width: 32, height: 32)
                .background(activity.color.opacity(0.1))
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(activity.title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text(activity.description)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 2) {
                if let amount = activity.amount {
                    Text("KSh \(Int(amount))")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.green)
                }
                
                Text(formatDate(activity.date))
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}

// MARK: - Supporting Types
enum TimeFrame {
    case week, month, year
}

struct SavingsDataPoint: Equatable {
    let date: Date
    let amount: Double
}

struct RecentActivity: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let date: Date
    let amount: Double?
    let icon: String
    let color: Color
}

// MARK: - Helper Functions
func generateSampleSavingsData() -> [SavingsDataPoint] {
    let calendar = Calendar.current
    var data: [SavingsDataPoint] = []
    
    for i in 0..<30 {
        let date = calendar.date(byAdding: .day, value: -i, to: Date()) ?? Date()
        let amount = Double.random(in: 50...300)
        data.append(SavingsDataPoint(date: date, amount: amount))
    }
    
    return data.reversed()
}

func generateRecentActivities() -> [RecentActivity] {
    return [
        RecentActivity(
            title: "Daily Savings",
            description: "Added to Emergency Fund Challenge",
            date: Date(),
            amount: 100,
            icon: "plus.circle.fill",
            color: .green
        ),
        RecentActivity(
            title: "Badge Earned",
            description: "Week Warrior - 7 day streak",
            date: Date().addingTimeInterval(-86400),
            amount: nil,
            icon: "star.fill",
            color: .yellow
        ),
        RecentActivity(
            title: "Challenge Completed",
            description: "Save KSh 50 Daily challenge",
            date: Date().addingTimeInterval(-86400 * 2),
            amount: 1500,
            icon: "checkmark.circle.fill",
            color: .blue
        ),
        RecentActivity(
            title: "Joined Challenge",
            description: "Education Fund challenge",
            date: Date().addingTimeInterval(-86400 * 3),
            amount: nil,
            icon: "person.badge.plus",
            color: .purple
        )
    ]
}

func formatDate(_ date: Date) -> String {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .none
    return formatter.string(from: date)
}

#Preview {
    SavingsProgressView()
} 