//
//  ProfileView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct ProfileView: View {
    @State private var user = User(
        name: "Natasha Gichuhi",
        email: "natasha@example.com",
        profileImageURL: nil,
        totalSaved: 15750,
        currentStreak: 12,
        longestStreak: 28,
        badges: Badge.sampleBadges,
        joinedChallenges: ["1", "2"],
        createdChallenges: ["1"],
        joinDate: Date().addingTimeInterval(-86400 * 30)
    )
    
    @State private var showingEditProfile = false
    @State private var showingSettings = false
    @State private var showingFriends = false
    
    var onLogout: (() -> Void)? = nil
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Profile header
                    profileHeader
                    
                    // Stats overview
                    statsOverview
                    
                    // Badges section
                    badgesSection
                    
                    // Achievement highlights
                    achievementHighlights
                    
                    // Settings and actions
                    settingsSection
                    
                    if let onLogout = onLogout {
                        Button(action: onLogout) {
                            Text("Logout")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color(hex: "034C45"))
                                .foregroundColor(.white)
                                .font(.system(size: 19, weight: .bold, design: .rounded))
                                .cornerRadius(14)
                                .shadow(color: Color(hex: "034C45").opacity(0.10), radius: 6, x: 0, y: 2)
                        }
                        .padding(.horizontal, 8)
                        .padding(.top, 8)
                    }
                }
                .padding()
                .background(Color(hex: "E6F2ED").ignoresSafeArea())
            }
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Edit") {
                        showingEditProfile = true
                    }
                    .foregroundColor(Color(hex: "034C45"))
                }
            }
            .sheet(isPresented: $showingEditProfile) {
                EditProfileView(user: $user)
            }
            .sheet(isPresented: $showingSettings) {
                SettingsView()
            }
            .sheet(isPresented: $showingFriends) {
                FriendsListView()
            }
        }
    }
    
    private var profileHeader: some View {
        VStack(spacing: 16) {
            // Profile image
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        colors: [.green, .blue],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 100, height: 100)
                
                Text(String(user.name.prefix(2)).uppercased())
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
            
            VStack(spacing: 4) {
                Text(user.name)
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text(user.email)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Text("Member since \(formatJoinDate(user.joinDate))")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    private var statsOverview: some View {
        VStack(spacing: 16) {
            Text("Your Impact")
                .font(.headline)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 12) {
                ProfileStatCard(
                    title: "Total Saved",
                    value: "KSh \(Int(user.totalSaved))",
                    icon: "banknote.fill",
                    color: .green
                )
                
                ProfileStatCard(
                    title: "Current Streak",
                    value: "\(user.currentStreak) days",
                    icon: "flame.fill",
                    color: .orange
                )
                
                ProfileStatCard(
                    title: "Challenges Joined",
                    value: "\(user.joinedChallenges.count)",
                    icon: "target",
                    color: .blue
                )
                
                ProfileStatCard(
                    title: "Badges Earned",
                    value: "\(user.badges.count)",
                    icon: "star.fill",
                    color: .yellow
                )
            }
        }
    }
    
    private var badgesSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Recent Badges")
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Button("View All") {
                    // Navigate to all badges
                }
                .foregroundColor(.green)
            }
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 12) {
                ForEach(user.badges.prefix(8)) { badge in
                    ProfileBadgeCard(badge: badge)
                }
            }
        }
    }
    
    private var achievementHighlights: some View {
        VStack(spacing: 16) {
            Text("Achievements")
                .font(.headline)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            VStack(spacing: 12) {
                AchievementRow(
                    title: "Longest Streak",
                    value: "\(user.longestStreak) days",
                    icon: "flame.fill",
                    color: .orange
                )
                
                AchievementRow(
                    title: "Challenges Created",
                    value: "\(user.createdChallenges.count)",
                    icon: "plus.circle.fill",
                    color: .blue
                )
                
                AchievementRow(
                    title: "Average Daily Savings",
                    value: "KSh \(Int(user.totalSaved / 30))",
                    icon: "chart.line.uptrend.xyaxis",
                    color: .green
                )
            }
        }
    }
    
    private var settingsSection: some View {
        VStack(spacing: 16) {
            Text("Settings & Support")
                .font(.headline)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            Button(action: { showingFriends = true }) {
                HStack {
                    Image(systemName: "person.2.fill")
                        .foregroundColor(.blue)
                    Text("Friends")
                        .fontWeight(.medium)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color(.white))
                .cornerRadius(10)
            }
            
            VStack(spacing: 0) {
                SettingsRow(
                    title: "Notifications",
                    icon: "bell.fill",
                    color: .orange
                ) {
                    showingSettings = true
                }
                
                Divider()
                
                SettingsRow(
                    title: "Privacy & Security",
                    icon: "lock.fill",
                    color: .blue
                ) {
                    showingSettings = true
                }
                
                Divider()
                
                SettingsRow(
                    title: "Help & Support",
                    icon: "questionmark.circle.fill",
                    color: .purple
                ) {
                    // Show help
                }
                
                Divider()
                
                SettingsRow(
                    title: "About wadz",
                    icon: "info.circle.fill",
                    color: .gray
                ) {
                    // Show about
                }
            }
            .background(Color(.systemBackground))
            .cornerRadius(12)
        }
        .sheet(isPresented: $showingFriends) {
            FriendsListView()
        }
    }
}

struct ProfileStatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.title2)
            
            Text(value)
                .font(.title3)
                .fontWeight(.bold)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color(.white))
        .cornerRadius(12)
    }
}

struct ProfileBadgeCard: View {
    let badge: Badge
    
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: badge.iconName)
                .foregroundColor(badge.category.color)
                .font(.title3)
                .frame(width: 36, height: 36)
                .background(badge.category.color.opacity(0.1))
                .cornerRadius(8)
            
            Text(badge.title)
                .font(.caption2)
                .fontWeight(.medium)
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
        .padding(8)
        .frame(maxWidth: .infinity)
        .background(Color(.systemBackground))
        .cornerRadius(8)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}

struct AchievementRow: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.title3)
                .frame(width: 32, height: 32)
                .background(color.opacity(0.1))
                .cornerRadius(8)
            
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
            
            Spacer()
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(color)
        }
        .padding()
        .background(Color(.white))
        .cornerRadius(10)
    }
}

struct SettingsRow: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .foregroundColor(color)
                    .font(.title3)
                    .frame(width: 24, height: 24)
                
                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
                    .font(.caption)
            }
            .padding()
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Helper Functions
func formatJoinDate(_ date: Date) -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "MMM yyyy"
    return formatter.string(from: date)
}

#Preview {
    ProfileView()
} 
