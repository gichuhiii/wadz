//
//  ChallengesView.swift
//  wadz
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import SwiftUI

struct ChallengesView: View {
    @State private var challenges = Challenge.sampleChallenges
    @State private var selectedCategory: ChallengeCategory? = nil
    @State private var showingCreateChallenge = false
    @State private var searchText = ""
    @State private var selectedFilter = 0 // 0: All, 1: Individual, 2: Group
    @State private var selectedChallenge: Challenge? = nil
    @State private var showJoinSuccess = false
    @State private var joinedChallengeTitle = ""
    @State private var nudgedFriend: String? = nil
    @State private var showNudgeAlert = false

    var filteredChallenges: [Challenge] {
        var filtered = challenges
        
        if selectedFilter == 1 {
            filtered = filtered.filter { !$0.isGroupChallenge }
        } else if selectedFilter == 2 {
            filtered = filtered.filter { $0.isGroupChallenge }
        }
        
        if let category = selectedCategory {
            filtered = filtered.filter { $0.category == category }
        }
        
        if !searchText.isEmpty {
            filtered = filtered.filter { 
                $0.title.localizedCaseInsensitiveContains(searchText) ||
                $0.description.localizedCaseInsensitiveContains(searchText)
            }
        }
        
        return filtered
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(hex: "E6F2ED").ignoresSafeArea()
                VStack(spacing: 0) {
                    // Search bar
                    searchBar
                    
                    // Filter tabs
                    filterTabs
                    
                    // Category filter
                    categoryFilter
                    
                    // Challenges list
                    challengesList
                }
                .navigationTitle("Challenges")
                .navigationBarTitleDisplayMode(.large)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button(action: { showingCreateChallenge = true }) {
                            Image(systemName: "plus")
                                .foregroundColor(.green)
                        }
                    }
                }
                .sheet(isPresented: $showingCreateChallenge) {
                    CreateChallengeView()
                }
            }
        }
    }
    
    private var filterTabs: some View {
        Picker("Filter", selection: $selectedFilter) {
            Text("All").tag(0)
            Text("Individual").tag(1)
            Text("Group").tag(2)
        }
        .pickerStyle(SegmentedPickerStyle())
        .padding(.horizontal)
        .padding(.vertical, 8)
    }
    
    private var searchBar: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.secondary)
            
            TextField("Search challenges...", text: $searchText)
                .textFieldStyle(PlainTextFieldStyle())
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .padding(.horizontal)
    }
    
    private var categoryFilter: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                CategoryChip(
                    title: "All",
                    isSelected: selectedCategory == nil
                ) {
                    selectedCategory = nil
                }
                
                ForEach(ChallengeCategory.allCases, id: \.self) { category in
                    CategoryChip(
                        title: category.rawValue,
                        isSelected: selectedCategory == category
                    ) {
                        selectedCategory = selectedCategory == category ? nil : category
                    }
                }
            }
            .padding(.horizontal)
        }
        .padding(.vertical, 10)
    }
    
    private var challengesList: some View {
        ScrollView {
            LazyVStack(spacing: 20) {
                ForEach(filteredChallenges) { challenge in
                    ChallengeListCard(
                        challenge: challenge,
                        onJoin: {
                            joinedChallengeTitle = challenge.title
                            showJoinSuccess = true
                        },
                        onDetails: {
                            selectedChallenge = challenge
                        },
                        onNudge: { friend in
                            nudgedFriend = friend
                            showNudgeAlert = true
                        },
                        currentUser: "Natasha Gichuhi"
                    )
                }
            }
            .padding()
        }
        .sheet(item: $selectedChallenge) { challenge in
            ChallengeDetailsView(challenge: challenge, currentUser: "Natasha Gichuhi")
        }
        .alert(isPresented: $showJoinSuccess) {
            Alert(title: Text("Joined!"), message: Text("You joined \(joinedChallengeTitle) 🎉"), dismissButton: .default(Text("OK")))
        }
        .alert(isPresented: $showNudgeAlert) {
            Alert(title: Text("Nudge Sent!"), message: Text("You nudged \(nudgedFriend ?? "") to save!"), dismissButton: .default(Text("OK")))
        }
    }
    
    private func joinChallenge(_ challenge: Challenge) {
        // Simulate joining challenge
        print("Joined challenge: \(challenge.title)")
    }
}

struct CategoryChip: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(isSelected ? Color.green : Color(.systemGray6))
                .foregroundColor(isSelected ? .white : .primary)
                .cornerRadius(20)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

struct ChallengeListCard: View {
    let challenge: Challenge
    let onJoin: () -> Void
    let onDetails: () -> Void
    let onNudge: (String) -> Void
    let currentUser: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: challenge.category.icon)
                            .foregroundColor(challenge.category.color)
                        Text(challenge.category.rawValue)
                            .font(.caption)
                            .foregroundColor(.secondary)
                        if challenge.isGroupChallenge {
                            Image(systemName: "person.3.fill")
                                .foregroundColor(.blue)
                        }
                    }
                    
                    Text(challenge.title)
                        .font(.headline)
                        .fontWeight(.semibold)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 2) {
                    Text("\(challenge.participants.count)")
                        .font(.headline)
                        .fontWeight(.bold)
                    Text("participants")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            // Avatars/Initials
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    let allParticipants = challenge.participants + (challenge.participants.contains(currentUser) ? [] : [currentUser])
                    ForEach(allParticipants, id: \.self) { name in
                        ZStack {
                            Circle()
                                .fill(name == currentUser ? Color.green.opacity(0.25) : Color.green.opacity(0.7))
                                .frame(width: 32, height: 32)
                            Text(initials(for: name) + (name == currentUser ? " (You)" : ""))
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(name == currentUser ? .green : .white)
                        }
                    }
                }
            }
            
            // Description
            Text(challenge.description)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .lineLimit(3)
            
            // Financial details
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Target Amount")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("KSh \(Int(challenge.targetAmount))")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Daily Goal")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("KSh \(Int(challenge.dailyAmount))")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Duration")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("\(challenge.duration) days")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                }
                
                // Progress bar
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text("Progress")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text("\(Int(challenge.progress * 100))%")
                            .font(.caption)
                            .fontWeight(.medium)
                    }
                    
                    ProgressView(value: challenge.progress)
                        .progressViewStyle(LinearProgressViewStyle(tint: challenge.category.color))
                }
            }
            
            // Action buttons
            HStack(spacing: 12) {
                Button(action: onJoin) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Join Challenge")
                    }
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing))
                    .cornerRadius(10)
                    .shadow(radius: 2)
                }
                
                Button(action: onDetails) {
                    HStack {
                        Image(systemName: "info.circle")
                        Text("Details")
                    }
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.green)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(10)
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: Color.green.opacity(0.08), radius: 8, x: 0, y: 2)
    }
    
    private func initials(for name: String) -> String {
        let comps = name.split(separator: " ")
        return comps.prefix(2).map { String($0.prefix(1)) }.joined().uppercased()
    }
}

struct ChallengeDetailsView: View {
    let challenge: Challenge
    // Mock participant savings data
    var participantSavings: [(name: String, amount: Double)] {
        // For demo, assign random savings to each participant
        let allNames = challenge.participants + (challenge.participants.contains(currentUser) ? [] : [currentUser])
        return allNames.enumerated().map { (i, name) in
            (name, Double(arc4random_uniform(1000) + 1000))
        }.sorted { $0.amount > $1.amount }
    }
    @State private var nudgedName: String? = nil
    @State private var showNudgeAlert = false
    let currentUser: String
    var body: some View {
        ZStack {
            Color(hex: "E6F2ED").ignoresSafeArea()
            ScrollView {
                VStack(spacing: 28) {
                    // Card container
                    VStack(spacing: 18) {
                        HStack(spacing: 12) {
                            Image(systemName: challenge.category.icon)
                                .foregroundColor(Color(hex: "034C45"))
                                .font(.system(size: 32, weight: .bold, design: .rounded))
                            Text(challenge.title)
                                .font(.system(size: 26, weight: .bold, design: .rounded))
                                .foregroundColor(Color(hex: "1B3333"))
                        }
                        Text(challenge.description)
                            .font(.system(size: 16, weight: .medium, design: .rounded))
                            .foregroundColor(Color(hex: "034C45").opacity(0.7))
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Divider()
                        HStack(alignment: .top, spacing: 24) {
                            VStack(alignment: .leading, spacing: 10) {
                                Label("Target: KSh \(Int(challenge.targetAmount))", systemImage: "target")
                                    .foregroundColor(Color(hex: "034C45").opacity(0.7))
                                Label("Daily: KSh \(Int(challenge.dailyAmount))", systemImage: "calendar")
                                    .foregroundColor(Color(hex: "034C45").opacity(0.7))
                                Label("Duration: \(challenge.duration) days", systemImage: "clock")
                                    .foregroundColor(Color(hex: "034C45").opacity(0.7))
                                Label("Category: \(challenge.category.rawValue)", systemImage: challenge.category.icon)
                                    .foregroundColor(Color(hex: "034C45").opacity(0.7))
                                Label("Participants: \(challenge.participants.count)", systemImage: "person.3.fill")
                                    .foregroundColor(Color(hex: "034C45").opacity(0.7))
                            }
                            Spacer()
                            VStack(alignment: .center, spacing: 8) {
                                let allParticipants = challenge.participants + (challenge.participants.contains(currentUser) ? [] : [currentUser])
                                ForEach(allParticipants, id: \.self) { name in
                                    ZStack {
                                        Circle()
                                            .fill(name == currentUser ? Color.green.opacity(0.25) : Color(hex: "034C45").opacity(0.12))
                                            .frame(width: 36, height: 36)
                                        Text(initials(for: name) + (name == currentUser ? " (You)" : ""))
                                            .font(.headline)
                                            .foregroundColor(name == currentUser ? .green : Color(hex: "034C45"))
                                    }
                                }
                            }
                        }
                        // Custom progress bar
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Progress")
                                .font(.caption)
                                .foregroundColor(Color(hex: "034C45").opacity(0.7))
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color(hex: "E6F2ED"))
                                    .frame(height: 14)
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color(hex: "034C45"))
                                    .frame(width: CGFloat(challenge.progress) * UIScreen.main.bounds.width * 0.7, height: 14)
                            }
                            Text("\(Int(challenge.progress * 100))% completed")
                                .font(.caption2)
                                .foregroundColor(Color(hex: "034C45"))
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(color: Color(hex: "1B3333").opacity(0.08), radius: 10, x: 0, y: 4)
                    // Leaderboard
                    VStack(spacing: 16) {
                        Text("Leaderboard")
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundColor(Color(hex: "1B3333"))
                            .frame(maxWidth: .infinity, alignment: .leading)
                        VStack(spacing: 10) {
                            ForEach(Array(participantSavings.enumerated()), id: \ .element.name) { index, entry in
                                HStack(spacing: 12) {
                                    ZStack {
                                        Circle()
                                            .fill(entry.name == currentUser ? Color.green.opacity(0.25) : Color(hex: "034C45").opacity(index == 0 ? 0.18 : 0.10))
                                            .frame(width: 36, height: 36)
                                        if index == 0 {
                                            Image(systemName: "medal.fill")
                                                .foregroundColor(Color(hex: "FFD700"))
                                                .font(.system(size: 18))
                                        } else if index == 1 {
                                            Image(systemName: "medal.fill")
                                                .foregroundColor(Color(hex: "C0C0C0"))
                                                .font(.system(size: 18))
                                        } else if index == 2 {
                                            Image(systemName: "medal.fill")
                                                .foregroundColor(Color(hex: "CD7F32"))
                                                .font(.system(size: 18))
                                        } else {
                                            Text(initials(for: entry.name) + (entry.name == currentUser ? " (You)" : ""))
                                                .font(.subheadline)
                                                .fontWeight(.bold)
                                                .foregroundColor(entry.name == currentUser ? .green : Color(hex: "034C45"))
                                        }
                                    }
                                    Text("#\(index + 1)")
                                        .fontWeight(index == 0 ? .bold : .regular)
                                        .foregroundColor(index == 0 ? Color(hex: "034C45") : Color(hex: "034C45").opacity(0.7))
                                    Text(entry.name + (entry.name == currentUser ? " (You)" : ""))
                                        .fontWeight(index == 0 ? .bold : .regular)
                                        .foregroundColor(entry.name == currentUser ? .green : (index == 0 ? Color(hex: "1B3333") : Color(hex: "034C45")))
                                    Spacer()
                                    Text("KSh \(Int(entry.amount))")
                                        .fontWeight(index == 0 ? .bold : .regular)
                                        .foregroundColor(index == 0 ? Color(hex: "034C45") : Color(hex: "034C45").opacity(0.7))
                                    // Nudge (poke) button only for other users
                                    if entry.name != currentUser {
                                        Button(action: {
                                            nudgedName = entry.name
                                            showNudgeAlert = true
                                        }) {
                                            Image(systemName: "hand.point.right.fill")
                                                .foregroundColor(Color(hex: "034C45"))
                                                .padding(6)
                                                .background(Color(hex: "E6F2ED"))
                                                .cornerRadius(8)
                                        }
                                        .buttonStyle(BorderlessButtonStyle())
                                    }
                                }
                                .padding(.vertical, 4)
                                .background(Color.white)
                                .cornerRadius(12)
                                .shadow(color: Color(hex: "1B3333").opacity(0.04), radius: 2, x: 0, y: 1)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(color: Color(hex: "1B3333").opacity(0.06), radius: 8, x: 0, y: 2)
                }
                .padding()
            }
        }
        .alert(isPresented: $showNudgeAlert) {
            Alert(title: Text("Nudge Sent!"), message: Text("You nudged \(nudgedName ?? "") to save!"), dismissButton: .default(Text("OK")))
        }
    }
    private func initials(for name: String) -> String {
        let comps = name.split(separator: " ")
        return comps.prefix(2).map { String($0.prefix(1)) }.joined().uppercased()
    }
}

#Preview {
    ChallengesView()
} 