//
//  wadzTests.swift
//  wadzTests
//
//  Created by Wangui Gichuhi on 12/06/2025.
//

import Testing

struct wadzTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
